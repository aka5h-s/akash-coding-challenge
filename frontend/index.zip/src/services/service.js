import http from "../http-common";

class PlayerService {
  // 1. Get all players
  getAllPlayers() {
    return http.get("/players/getall");
  }

  // 2. Add new player
  addPlayer(data) {
    return http.post("/players/add", data);
  }

  // 3. Update existing player
  updatePlayer(id, data) {
    return http.put(`/players/update/${id}`, data);
  }

  remove(id) {
  return http.delete(`/players/deletebyid/${id}`);
}
}

export default new PlayerService();
