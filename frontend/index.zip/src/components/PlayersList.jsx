import { useEffect, useState } from "react";
import PlayerService from "../services/service";
import { Link } from "react-router-dom";

export default function PlayersList() {
  const [players, setPlayers] = useState([]);

  const fetchPlayers = () => {
    PlayerService.getAllPlayers()
      .then((response) => {
        setPlayers(response.data);
      })
      .catch((error) => {
        console.error("Error fetching players:", error);
      });
  };

  useEffect(() => {
    fetchPlayers();
  }, []);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this player?")) {
      PlayerService.remove(id)
        .then(() => {
          alert("Player deleted successfully!");
          fetchPlayers(); 
        })
        .catch((err) => {
          console.error("Delete failed:", err?.response || err);
          alert("Failed to delete player!");
        });
    }
  };

  return (
    <div>
      <h4 className="mb-3">Players List</h4>

      <div className="table-responsive">
        <table className="table table-striped table-bordered align-middle">
          <thead className="table-light">
            <tr>
              <th>Player ID</th>
              <th>Name</th>
              <th>Jersey Number</th>
              <th>Role</th>
              <th>Total Matches</th>
              <th>Team Name</th>
              <th>Country / State</th>
              <th>Description</th>
              <th style={{ width: 160 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {players.length > 0 ? (
              players.map((p) => (
                <tr key={p.playerId}>
                  <td>{p.playerId}</td>
                  <td>{p.playerName}</td>
                  <td>{p.jerseyNumber}</td>
                  <td>{p.role}</td>
                  <td>{p.totalMatches}</td>
                  <td>{p.teamName}</td>
                  <td>{p.countryOrState}</td>
                  <td>{p.description}</td>
                  <td>
                    <Link
                      to={`/update/${p.playerId}`}
                      className="btn btn-sm btn-primary me-2"
                    >
                      Edit
                    </Link>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(p.playerId)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="9" className="text-center">
                  No players found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
